﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppBMI_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float ves = float.Parse(textBox2.Text);
            float rost = float.Parse(textBox1.Text);
            float index = ves / ((rost / 100) * (rost / 100));
            label8.Text = index.ToString();
            trackBar1.Value = Convert.ToInt32(index);
            if (index < 18.5)
            { pictureBox3.Image = Image.FromFile(@"C:\Users\User\source\repos\WindowsFormsAppBMI_Calculator\WindowsFormsAppBMI_Calculator\image\bmi-underweight-icon.png"); }
            else 
                if (index < 25)
            { pictureBox3.Image = Image.FromFile(@"C:\Users\User\source\repos\WindowsFormsAppBMI_Calculator\WindowsFormsAppBMI_Calculator\image\bmi-healthy-icon.png"); }
            else
                if (index < 30)
            { pictureBox3.Image = Image.FromFile(@"C:\Users\User\source\repos\WindowsFormsAppBMI_Calculator\WindowsFormsAppBMI_Calculator\image\bmi-overweight-icon.png"); }
            else
                if (index > 30)
            { pictureBox3.Image = Image.FromFile(@"C:\Users\User\source\repos\WindowsFormsAppBMI_Calculator\WindowsFormsAppBMI_Calculator\image\bmi-obese-icon.png"); }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox1.Image;

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox2.Image;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 frm3 = new
            Form3();
            frm3.Show();
            this.Hide();
        }
    }
}
